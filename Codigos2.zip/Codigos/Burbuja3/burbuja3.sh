#!/bin/bash
gcc BurbujaOptimizada2.c tiempo.c -o burbuja3
./burbuja3 100 <numeros10millones.txt >> burbuja3.txt
./burbuja3 1000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 5000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 10000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 20000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 30000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 40000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 50000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 60000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 70000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 80000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 90000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 100000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 150000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 200000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 250000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 300000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 400000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 500000 <numeros10millones.txt >> burbuja3.txt
./burbuja3 600000 <numeros10millones.txt >> burbuja3.txt


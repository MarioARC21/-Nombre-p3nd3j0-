#!/bin/bash
gcc arbol.c tiempo.c -o arbol
./arbol 100 <numeros10millones.txt > arbol.txt
./arbol 1000 <numeros10millones.txt > arbol.txt
./arbol 5000 <numeros10millones.txt > arbol.txt
./arbol 10000 <numeros10millones.txt > arbol.txt
./arbol 50000 <numeros10millones.txt > arbol.txt
./arbol 100000 <numeros10millones.txt > arbol.txt
./arbol 200000 <numeros10millones.txt > arbol.txt
./arbol 400000 <numeros10millones.txt > arbol.txt
./arbol 600000 <numeros10millones.txt > arbol.txt
./arbol 800000 <numeros10millones.txt > arbol.txt
./arbol 1000000 <numeros10millones.txt > arbol.txt
./arbol 2000000 <numeros10millones.txt > arbol.txt
./arbol 3000000 <numeros10millones.txt > arbol.txt
./arbol 4000000 <numeros10millones.txt > arbol.txt
./arbol 5000000 <numeros10millones.txt > arbol.txt
./arbol 6000000 <numeros10millones.txt > arbol.txt
./arbol 7000000 <numeros10millones.txt > arbol.txt
./arbol 8000000 <numeros10millones.txt > arbol.txt
./arbol 9000000 <numeros10millones.txt > arbol.txt
./arbol 10000000 <numeros10millones.txt > arbol.txt
./arbol 500000 <numeros10millones.txt > arbol.txt


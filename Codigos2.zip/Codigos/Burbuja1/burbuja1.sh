#!/bin/bash
gcc BurbujaSimple.c tiempo.c -o burbuja1
./burbuja1 100 <numeros10millones.txt > burbuja1.txt
./burbuja1 1000 <numeros10millones.txt > burbuja1.txt
./burbuja1 5000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 10000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 20000 <numeros10millones.txt > burbuja1.txt
./burbuja1 30000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 40000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 50000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 60000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 70000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 80000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 90000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 100000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 150000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 200000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 250000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 300000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 400000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 500000 <numeros10millones.txt >> burbuja1.txt
./burbuja1 600000 <numeros10millones.txt >> burbuja1.txt


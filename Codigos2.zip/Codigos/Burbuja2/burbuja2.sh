#!/bin/bash
gcc BurbujaOptimizada1.c tiempo.c -o burbuja2
./burbuja2 100 <numeros10millones.txt >> burbuja2.txt
./burbuja2 1000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 5000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 10000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 20000 <numeros10millones.txt > burbuja2.txt
./burbuja2 30000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 40000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 50000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 60000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 70000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 80000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 90000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 100000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 150000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 200000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 250000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 300000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 400000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 500000 <numeros10millones.txt >> burbuja2.txt
./burbuja2 600000 <numeros10millones.txt >> burbuja2.txt


